# RouteAI – Offline-First Smart Logistics Navigation

RouteAI keeps the original features and adds an **offline-first field workflow** designed for NER/remote and weak-signal roads.

## Original features retained
- Official / public sign-in
- From + To search and map selection
- Multiple real-road routes via OSRM
- Route comparison with distance/time
- Blockage + weather analysis
- Geo-tagged photo reports
- All-routes-blocked alert simulation
- Official/public role tracking

## New features
### 1. Offline Incident Capture
Use **🚨 Quick Report** to save flood, landslide, accident, road damage, traffic, or blocked-road reports even with no mobile data. The report is stored locally in IndexedDB and automatically syncs when connectivity returns.

### 2. Offline Route Continuity
Previously successful routes are cached on the device. If the signal drops, RouteAI first tries the cached route; if none exists, it shows a clearly labelled straight-line fallback so the user can still record and review the trip.

### 3. Connection-aware UI
A persistent Online/Offline banner, pending-report count, cached-route count, and **Sync Now** control make the data state visible instead of hiding failures.

### 4. PWA shell
The app shell is cached by a service worker after the first online load, so the main interface can reopen during temporary connectivity loss.

### 5. Incident context
Reports include incident type and severity, in addition to GPS, description, user and timestamp. This gives officials structured field data instead of only free-text photos.

## What makes the approach different
The key differentiator is **Signal-Safe Reporting**: the application treats connectivity loss as a normal operating condition. A field worker can collect structured, geo-tagged evidence first and synchronize later, rather than requiring a live connection at the moment of collection.

## Run locally
```bash
cd backend
npm install
npm start
```
Open `http://localhost:3000`.

Default accounts:
- admin / admin123 – official
- officer1 / pass123 – official
- user1 / user123 – public
- citizen / citizen – public

## Important limitation
Live OSRM routing, OpenStreetMap tiles, and live weather still require connectivity. Offline mode is intentionally explicit: cached routes are labelled as cached, and the straight-line fallback is labelled as a fallback. This prevents stale/offline data from being mistaken for live road intelligence.


### New report management
- Remove uploaded geo-tagged photos/reports from the map popup or Saved Data panel.
- Remove pending Quick Reports before they sync.
- Public users can remove their own reports; officials can remove reports for moderation.
- Offline reports remain on-device until synced or manually removed.
- Fixed async upload/quick-report handlers so the frontend JavaScript runs correctly.
